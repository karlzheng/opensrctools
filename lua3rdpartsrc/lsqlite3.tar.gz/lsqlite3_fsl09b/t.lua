local sqlite = require("lsqlite3")

local db = sqlite("mydata.db", "wc")
local sm = db:prepare [[
  create table person(
    id integer primary key,
    name text not null,
    email text,
    phone text);
]]
sm:step()
sm:finalize()
db:close()
