LIB_PATH=`pwd` INC_PATH=`pwd` LD=arm-linux-ld CC=arm-linux-gcc make linux 
